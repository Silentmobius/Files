#Programmer: Jimmy Lim
#Date: 7/31/18
#Class: CSCI 1511
#Project 2

import sys, os, math, livewires
from livewires import games, color
from spriteUtils import *


games.init(screen_width = 1024, screen_height = 768, fps = 50)
filename = 'runningcat.png'
x = 512
y = 256

class Character(games.Animation):
    yelp = games.load_sound(os.path.join('sounds', 'yahoo-1.wav'))
    laugh = games.load_sound(os.path.join('sounds', 'crowd-laughing.wav'))
    STEP = 4
    FLOOR = 0
    GRAVITY = 0.20
    THRUST = -10
    POP = -12
    
    def __init__(self, animList, x, y, floor):
        super(Character, self).__init__(images = animList,
                                        x = x,
                                        y = y,
                                        n_repeats = -1,
                                        repeat_interval = 10)
        Character.FLOOR = floor
        self.yVel = 0
        self.is_jumping = False
        self.jumpList = [animList[4]]
        self.standList = [animList[6]]
        self.animList = animList     

    def update(self):
#Gravity and jumping        
        if not self.is_jumping:
            if games.keyboard.is_pressed(games.K_SPACE):
                Character.yelp.play()
                self.yVel = Character.THRUST
                self.is_jumping = True
                self.images = self.jumpList
        else:
            self.y += math.floor(self.yVel)
            self.yVel += Character.GRAVITY

            if self.y >= Character.FLOOR:
                self.is_jumping = False
                self.yVel = 0
                self.y = Character.FLOOR
                self.images = self.animList

        if games.keyboard.is_pressed(games.K_a):
            self.x -= 10
        if games.keyboard.is_pressed(games.K_d):
            self.x += 10
#Colliding with other sprites
                
        if self.left > games.screen.width:
            self.right = 0
        if self.right < 0:
            self.left = games.screen.width

        self.check_collisions()
        
    def check_collisions(self):
        for obj in self.overlapping_sprites:
            self.handle_collision()
            
    def handle_collision(self):
        Character.laugh.play()
        self.left = games.screen.width + 10
#Object class for Sprites        
class Objects(games.Sprite):
    def __init__(self, name, x, y, img, col, dx, dy):
        super(Objects, self).__init__(image = img,
                                      x = x, y = y,
                                      is_collideable = col,
                                      dx = dx,
                                      dy = dy)

        self.name = name
    def getName(self):
        return self.name
    
    def update(self):
        if self.top > games.screen.height:
            self.bottom = games.screen.height - 650

        if self.bottom < 0:
            self.top = 0

class Score(games.Sprite):
    chef_image = games.load_image(os.path.join('assets', 'chef.bmp'))

    def __init__(self):
        super(Score, self).__init__(image = Score.chef_image,
            x = games.mouse.x,
            bottom = games.screen.height)
        self.score = games.Text(value = 0, size = 25, color = color.black,
            top = 5, right = games.screen.width - 10)
        games.screen.add(self.score)

def main():
    games.music.load("theme.mid")
    games.music.play(-1)
    
    bkgnd_image = games.load_image(os.path.join('assets', "BG_1.png"), transparent = 0)
    games.screen.background = bkgnd_image

    chef_image = games.load_image(os.path.join('assets', 'chef.bmp'))
    rock_image = games.load_image(os.path.join('assets', 'asteroid_big.bmp'))
    chef = Objects("chef",
                   5*games.screen.width/8,
                   70,
                   chef_image,
                   True,
                   0,
                   0)
    rock = Objects("rock",
                   5*games.screen.width/8,
                   70,
                   rock_image,
                   True,
                   0,
                   5)
    
    anim_list = load_2d_sheets(x, y, filename)
    anim1 = Character(anim_list,
                     games.screen.width/6,
                     games.screen.height/2,
                     games.screen.height/2)

    games.screen.add(anim1)
    games.screen.add(chef)
    games.screen.add(rock)
    games.screen.mainloop()

main()

