<?php
$page_title = "Mission Statement";
include ("./includes/header.inc.html");
?>
<div class="missionbg-1 container-fluid text-center">
		<h2>MISSION STATEMENT</h2>
		<img src="./images/WoW.PNG" alt="South Park Character" class="img-circle">
		<h3>To become an employee of a new company for someone else's mission statement</h3>
		</div><?php
include ("./includes/footer.inc.html");
exit();
?>