drop database if exists logindb;
create database if not exists logindb;
use logindb;
CREATE TABLE relationshipTable (
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Description NVARCHAR(50) NOT NULL
);
INSERT INTO relationshipTable (Description)
	VALUES ('Supervisor'), ('Mentor'), ('Instructor'), ('Classmate'), ('Site Visitor'), ('Other');
CREATE TABLE referencesTable (
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `Yes/No` NVARCHAR(5) NULL
);
INSERT INTO referencesTable (`Yes/No`)
	VALUES  ('Yes'), ('No');
    
CREATE TABLE messageTable (
	id int unsigned auto_increment not null primary key,
    firstName nvarchar(255) NOT NULL,
    lastName nvarchar(255) NOT NULL,
    email nvarchar(255) NOT NULL,
    messageSentDate DATETIME NULL
);
#INSERT INTO messageTable (email, messageSentDate) VALUES ('jlim@cap', NOW());
select * from messageTable;
CREATE TABLE users(
	id int unsigned auto_increment not null primary key,
	userName nvarchar(255) not null,
    firstName nvarchar(255) not null,
    lastName nvarchar(255) not null,
    phoneNumber nvarchar(255) null,
	registrationDate DATETIME NULL,
    pass_hash char(60) not null,
    unique(userName),
    relationshipId int unsigned,
    referencesId int unsigned,
    CONSTRAINT FOREIGN KEY Relationship_FK (relationshipId)
		REFERENCES relationshipTable (id),
    CONSTRAINT FOREIGN KEY References_FK (referencesId)
		REFERENCES referencesTable (id)
);
#INSERT INTO users (userName, firstName, lastName, phoneNumber, registrationDate, pass_hash, relationshipId, referencesId, messageSentId)
#VALUES ('Jim', 'Jim', 'Jim', '614-234', '1234', NOW(), 1234, 1, 1, 1);
SELECT * FROM users;
CREATE TABLE `Tiers` (
	`id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `Description` NVARCHAR(50) NOT NULL
);
INSERT INTO `Tiers` (`Description`)
	VALUES  ('Front-end'),
			('Back-end'),
			('Object-Oriented'),
            ('Other');
CREATE TABLE `Programming_Languages` (
	`id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `Language` NVARCHAR(50) NOT NULL,
    `Tier_id` INT UNSIGNED,
    
	CONSTRAINT FOREIGN KEY `Tier_FK` (`Tier_id`)
		REFERENCES `Tiers` (`id`)
);
INSERT INTO `Programming_Languages` (`Language`, `Tier_id`)
	VALUES  ('HTML/CSS', 1),
			('Javascript', 1),
            ('Database Fundamentals (SQL)', 2),
            ('Visual Basic', 3),
            ('Java', 3),
            ('C#', 3),
            ('Python', 3);
            
#SELECT * from users;