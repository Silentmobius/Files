<?php
$page_title = "Images";
include ("./includes/header.inc.html");
?>

<p>Click on an image to view it in a separate window.</p>
<ul>
<?php 
	$dir = "./uploads";
	$files = scandir($dir);
	foreach ($files as $image) {
		if (substr($image, 0, 1) != '.') {
			$image_size = getimagesize("$dir/$image");
			$image_name = urlencode($image);
			
			echo "<li><ahref=\"javascript:create_window('$image_name', $image_size[0],$image_size[1])\">$image</a></li>\n";
	}
	}
?>
</ul>