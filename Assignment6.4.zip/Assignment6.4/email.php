<?php
$page_title = "Email";
include ("./includes/header.inc.html");
?>
<h1>Contact me</h1>
<p>Please fill out this form to contact me</p>
<?php
//phpinfo();
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	if(!empty($_POST['firstName']) && !empty($_POST['lastName']) && !empty($_POST['email']) && !empty($_POST['comments'])){
		$body = "Name: {$_POST['firstName']}" . " " . "{$_POST['lastName']} \n\n Comment: {$_POST['comments']}";
		$body = wordwrap($body, 70);
		

		
		
		if (isset($_POST['firstName'])){
			$firstName = $_POST['firstName'];
		}
		if (isset($_POST['lastName'])){
			$lastName = $_POST['lastName'];
		}
		if (isset($_POST['email'])){
			$email = $_POST['email'];
		}
		$q = "INSERT INTO messageTable (firstName, lastName, email, messageSentDate) VALUES ('$firstName', '$lastName', '$email', NOW());";
		$r = mysqli_query($dbc, $q);
		$num = mysqli_affected_rows($dbc);
		if ($num == 1){
			echo "<p><em>Thank you {$_POST['firstName']}.  Your message has been sent.</em></p>";
			mail ('jlim5@student.cscc.edu', 'Contact Form Submission', $body, 'From: $_POST["email"]');
		} else {
			echo mysqli_error($dbc);
		}
		//Clears the array
		$_POST = array();
	} else {
		echo "<p style='font-weight: bold; color: red'>Please fill out the entire form completely</p>";
	}
}


?>


<form action="email.php" method="POST">
<label><p>First Name:</p><input type="text" name="firstName" value="" size = "30" maxlength = "60" /></label>
<label><p>Last Name:</p><input type="text" name="lastName" value="" size = "30" maxlength = "60" /></label>
<label><p>Email:</p><input type="text" name="email" value="" size="30" maxlength = "80" /></label>
<label><p>Comment:</p><textarea rows="5" cols="30" name="comments" value="" ></textarea></label><br><br>
<input type="submit" value="Send">
</form>
<?php
include ("./includes/footer.inc.html");
exit();
?>