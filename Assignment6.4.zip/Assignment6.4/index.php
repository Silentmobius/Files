<?php
$page_title = "Login";
include ("./includes/header.inc.html");
require ('./includes/login_functions.inc.php');
?>
<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	list($check, $data) = check_login($dbc, $_POST['username'], $_POST['password']);
	if ($check){
		
		session_start();
		$_SESSION['ID'] = $data['id'];
		$_SESSION['Username'] = $data['username'];
		
		$_SESSION['Agent'] = md5($_SERVER['HTTP_USER_AGENT']);
		//setcookie('ID', $data['id']);
		//setcookie('Username', $data['username']);
		redirect_user('loggedin.php');
	} else {
		$errors = $data;
	}
	mysqli_close($dbc);
}
include ('./includes/login_page.inc.php');


?>
<?php
include ("./includes/footer.inc.html");
exit();
?>