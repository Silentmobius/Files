<?php

include ("./includes/header.inc.html");
include ('./includes/login_functions.inc.php');
	if (!isset($_SESSION['Agent']) OR $_SESSION['Agent'] != md5($_SERVER['HTTP_USER_AGENT'])){
		
		redirect_user();
		
	} else {
		$page_title = "Loggedin";
		echo "<h1 class='whiteText'>WELCOME TO THE HOMEPAGE</h1>";
		echo "<p>Welcome {$_SESSION['Username']}!</p>";
		echo '
		<div class="bg-1 container-fluid text-center">
		<h2>Who Am I?</h2>
		<img src="./images/tiger.PNG" alt="Tiger" class="img-circle">
		<h3>Im an adventurer</h3>
		</div>
		
		<div class="container-fluid bg-2 text-center">
			<h2>What Am I?</h2>
			<h3>Software Developer</h3>
			</a>
		</div>
		
		<div class="container-fluid bg-3 text-center">
		<h3>Where To Find Me?</h3>
		<p>Pickerington, Ohio</p>
		</div>
		
		';
		
	}



include ("./includes/footer.inc.html");
?>