<?php
$page_title = "Update Languages";
include ("./includes/header.inc.html");
require ('./includes/login_functions.inc.php');
?>
<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	$data = '';
	if (empty($_POST['newLanguage']) OR empty($_POST['newTier'])){
		$errors[] = '<p>Fields are empty</p>';
	} else {
		list($check, $data) = check_languages($dbc, $_POST['oldLanguage'] , $_POST['oldTier']);
		if ($check){
			$oldLanguage = $_POST['oldLanguage'];
			$oldTier = $_POST['oldTier'];
			$newLanguage = $_POST['newLanguage'];
			$newTier = $_POST['newTier'];
				$qq = "UPDATE Programming_Languages SET Language = '$newLanguage', Tier_id = $newTier WHERE id =" . $data['id'] . ";";		
				$r = mysqli_query($dbc, $qq);
				$numAffected = mysqli_affected_rows($dbc);
				if ($numAffected == 1){
					echo "<p>Thank you.  You've successfully updated your password.</p>";
				} else {
					echo mysqli_error($dbc);
				}
		mysqli_close($dbc);
		} else {
			$errors = $data;
		}
	}
}
include ('./includes/updateLanguages_page.inc.php');


?>
<?php
include ("./includes/footer.inc.html");
exit();
?>