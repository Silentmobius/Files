<?php
$page_title = "Login";
include ("./includes/header.inc.html");

?>
<?php
$userErr = $passErr = $confirmPassErr = "";
$r = FALSE;
	if ($_SERVER['REQUEST_METHOD'] == "POST"){
		if (empty($_POST['userID'])) {
			$userErr = "Please enter your username";
		} else {
			//mysqli function provides extra security against hackers that may attack the database
			$userID = mysqli_real_escape_string($dbc, trim($_POST['userID']));
		}
		if (empty($_POST['password'])){
			$passErr = "Please enter a password";
		} else {
			$password = mysqli_real_escape_string($dbc, trim($_POST['password']));
		}
	}
		if (!empty($userID) && !empty($password)){
			
			$q = "SELECT id FROM users WHERE username = '" . $userID . "' AND pass_hash = '" . $password . "'";
			//Query
			//Execute the query with $r becoming TRUE or FALSE
			$r = mysqli_query($dbc, $q);
			//Validate query was made
			if (mysqli_num_rows($r) == 1){
				echo "<p>You are logged in!</p>";
				exit();
			} else {
				echo "<p>Incorrect Login</p>";
			}
			//Close the db (optional)
			mysqli_close($dbc);
		}
//Debugging tools
//print_r($userErr); var_dump();
?>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <fieldset>
    <legend>Login</legend>
	<p>Required *</p>
    User ID: *<br>
    <input type="text" name="userID" value="<?php if (isset($_POST['userID'])) echo $_POST['userID']?>"><span class="error">*<?php if(empty($_POST['userID'])) echo $userErr ?></span><br>
	Password *<br>
	<input type="text" name="password" value=""/><span class="error">*<?php if(empty($_POST['password'])) echo $passErr ?></span><br>
    <input type="submit" value="Submit">
  </fieldset>
</form>
<?php
include ("./includes/footer.inc.html");
?>
