<?php
$page_title = "Change Password";
include ("./includes/header.inc.html");
include ('./includes/login_functions.inc.php');
?>
<?php
$userErr = $passErr = $confirmPassErr = "";
$r = FALSE;
if (isset($_GET['id'])){
	$id = $_GET['id'];
	$q = "SELECT username FROM users WHERE id=" . $id;
	$r = mysqli_query($dbc, $q);
	if (mysqli_num_rows($r) == 1){
		$row = mysqli_fetch_array($r, MYSQLI_ASSOC);
		$userName = $row['username'];
	}
}
	if ($_SERVER['REQUEST_METHOD'] == "POST"){
		if (empty($_POST['userID'])) {
			$userErr = "Please enter your username";
		} else {
			//mysqli function provides extra security against hackers that may attack the database
			$userID = mysqli_real_escape_string($dbc, trim($_POST['userID']));
		}
		if (empty($_POST['oldPassword']) || empty($_POST['newPassword'])){
			$passErr = "Please enter a password";
		}
		if (empty($_POST['confirmPassword'])){
			$confirmPassErr = "Please confirm your password.";
		} else {
				if ($_POST['newPassword'] != $_POST['confirmPassword']){
					echo "New password and Confirmation do not match.";
				} else {
					$newPassword = mysqli_real_escape_string($dbc, trim($_POST['newPassword']));
					$confirmPass = $_POST['confirmPassword'];
				}
		}
		if (!empty($userID) && !empty($newPassword) && !empty($confirmPass)){
			if ($_POST['oldPassword'] == $_POST['newPassword']){
				echo "New password is the same as the old one.";
			} else {
				$qq = "SELECT id FROM users WHERE username='$userID' AND pass_hash = '" . $_POST['oldPassword'] . "'";
				$rr = mysqli_query($dbc, $qq);
				$num = mysqli_num_rows($rr);
				if ($num == 1) {
					$row = mysqli_fetch_array($rr, MYSQLI_ASSOC);
					$q = 'UPDATE users SET pass_hash = "' . $newPassword . '" WHERE id =' . $row['id'];
					$r = mysqli_query($dbc, $q);
					$numAffected = mysqli_affected_rows($dbc);
					if ($numAffected == 1){
						echo "<p>Thank you.  You've successfully updated your password.</p>";
					} else {
						echo mysqli_error($dbc);
					}
				} else {
					echo "User not found in the database";
				}
				//Close the db (optional)
				mysqli_close($dbc);
			}
		}
	}
?>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <fieldset>
    <legend>Change Password</legend>
	<p>Required *</p>
    User ID: *<br>
    <input type="text" name="userID" value="<?php echo isset($userName) ? $userName : '' ?>"><span class="error">*<?php if(empty($_POST['userID'])) echo $userErr ?></span><br>
	Password *<br>
	<input type="text" name="oldPassword" value=""/><span class="error">*<?php if(empty($_POST['oldPassword'])) echo $passErr ?></span><br>
	New Password *<br>
	<input type="text" name="newPassword" value=""/><span class="error">*<?php if(empty($_POST['newPassword'])) echo $passErr ?></span><br>
	Confirm Password *<br>
	<input type="text" name="confirmPassword" value=""/><span class="error">*<?php if(empty($_POST['confirmPassword'])) echo $confirmPassErr ?></span><br>
    <input type="submit" value="Submit">
  </fieldset>
</form>
<?php
include ("./includes/footer.inc.html");
exit();
?>