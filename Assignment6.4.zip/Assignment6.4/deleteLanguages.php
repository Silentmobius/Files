<?php
$page_title = "Delete Languages";
include ("./includes/header.inc.html");
echo "<h1>Deleting Language</h1>";
?>
<?php



if (isset($_GET['id'])) {
	$id = $_GET['id'];
	$q = "SELECT Language FROM Programming_Languages WHERE id=" . $id;
	$r = mysqli_query($dbc, $q);
	if (mysqli_num_rows($r) == 1){
		$rows = mysqli_fetch_array($r, MYSQLI_ASSOC);
		echo "<p>Are you sure you want to delete " . $rows['Language'] . "? </p>";
	}
} else {
	echo "<p>Id cannot be found</p>";
	exit();
}
?>
<?php
if ($_SERVER['REQUEST_METHOD'] == "POST" && (!empty($_GET['id']))){
	if (isset($_POST['check'])){
		if ($_POST['check'] == 'Yes'){
			$q = "DELETE from Programming_Languages WHERE id =" . $_GET['id'];
			$r = mysqli_query($dbc, $q);
			$num = mysqli_affected_rows($dbc);
			if ($num == 1){
				echo "<br><br><p>You have deleted the language</p>";
				exit();
			} else {
				echo "<p>No language is selected</p>";
			}
		} elseif ($_POST['check'] =='No') {
			echo " <br><p>Then what are you doing here?</p>";
		} else {
			echo '';
		}
	} else {
		echo "<p>Please select an option</p>";
	}
}
?>
<?php 
echo 
"<form method='POST' action='deleteLanguages.php?id=" . $_GET['id'] . "'" . ">
<p><input type='radio' name='check' value = 'Yes'>Yes
<input type='radio' name='check' value = 'No' >No</p>
<input type='submit' value='Submit'>

</form>
";
?>
<?php
include ("./includes/footer.inc.html");
exit();
?>