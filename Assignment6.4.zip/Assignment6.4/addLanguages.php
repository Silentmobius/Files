<?php
$page_title = "Languages";
include ("./includes/header.inc.html");
?>
<?php
$tierErr = $passErr = $langErr = "";
$r = FALSE;
	if ($_SERVER['REQUEST_METHOD'] == "POST"){
		if (empty($_POST['tier'])) {
			$tierErr = "Please select a tier.";
		} else {
			//mysqli function provides extra security against hackers that may attack the database
			$tierID = mysqli_real_escape_string($dbc, trim($_POST['tier']));
		}
		if (empty($_POST['newLanguage'])){
			$langErr = "Please enter a language.";
		} else {
			$newLanguage = mysqli_real_escape_string($dbc, trim($_POST['newLanguage']));
		}
		if (!empty($tierID) && !empty($newLanguage) ){
			//Query
			$q = "INSERT INTO Programming_Languages (Language, Tier_id) VALUES ('$newLanguage', $tierID);";
			//Execute the query with $r becoming TRUE or FALSE
			$r = mysqli_query($dbc, $q);
			//Validate query was made
			if ($r){
				echo "<p>You've successfully added a new language!</p>";
			} else {
				echo "<p>$newLanguage $tierID</p>";
			}
			//Close the db (optional)
			mysqli_close($dbc);
		}

	}
//Debugging tools
//print_r($userErr); var_dump();
?>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <fieldset>
    <legend><h1>ADD LANGUAGE</h1></legend>
	<p>Required *</p>
	<p><label>Tier:</label>
		<select name="tier">
		<option></option>
		<option value="1">Front-end</option>
		<option value="2">Back-end</option>
		<option value="3">Object-Oriented</option>
		<option value="4">Other</option>
		</select>
	<span class="error">*<?php if(empty($_POST['tier'])) echo $tierErr ?></span></p>
	<br>
	<p>Programming Language *</p>
	<input type="text" name="newLanguage" value=""/><span class="error">*<?php echo (empty($_POST['newLanguage'])) ? $langErr : ''?></span><br><br>
    <input type="submit" value="Submit">
  </fieldset>
</form>
<?php
	if ($r == TRUE) {
		echo '<p>Never stop learning</p>';
	}
?>
<?php
include ("./includes/footer.inc.html");
exit();
?>