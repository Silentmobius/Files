<?php
$page_title = "References";
include ("./includes/header.inc.html");
?>
<div class="hobbiesbg-1 container-fluid text-center">
		<h2>HOBBIES</h2>
		<img src="./images/rooster.PNG" alt="Rooster" width="200px" height="200px">
		<h3>He listens gud.</h3>
		<img src="./images/fox.PNG" alt="Rooster" width="200px" height="200px">
		<h3>Not deceptive enough for the office.</h3>
		<img src="./images/cartoon.PNG" alt="Cartoon" width="200px" height="200px">
		<h3>Really hates Accounting.  I'm just glad we underpaid him for 2 years lol.</h3>
		</div>
<?php
include ("./includes/footer.inc.html");
exit();
?>