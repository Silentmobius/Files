<?php
$page_title = "View Messengers";
include ("./includes/header.inc.html");
?>
<?php
//Pagination
$display = 5;
if (isset($_GET['p']) && is_numeric($_GET['p'])){
	$pages = $_GET['p'];
} else {
	$q = "SELECT COUNT(id) from messageTable";
	$r = mysqli_query($dbc, $q);
	$row = mysqli_fetch_array($r, MYSQLI_NUM);
	$records = $row[0];
	if ($records > $display){
		$pages = ceil($records/$display);
	} else {
		$pages = 1;
	}
}
if (isset($_GET['s']) && is_numeric($_GET['s'])){
	$start = $_GET['s'];
} else {
	$start = 0;
}

$sort = (isset($_GET['sort'])) ? $_GET['sort'] : 'id'; 

switch ($sort) {
	case 'firstName':
		$order_by = 'firstName ASC'; break;
	case 'lastName':
		$order_by = 'lastName ASC'; break;
	case 'email':
		$order_by = 'email ASC'; break;
	case 'messageSentDate':
		$order_by = 'messageSentDate ASC'; break;
	case 'id':
		$order_by = 'id ASC'; break;
}
//Query
$r = FALSE;
$q = "SELECT id, firstName, lastName, email, DATE_FORMAT(messageSentDate, '%M %d, %Y') AS date from messageTable ORDER BY $order_by LIMIT $start, $display";
$r = mysqli_query($dbc, $q);
//mysqli_num_rows($r) counts the # of rows from the SELECT statement
$num = mysqli_num_rows($r);
if ($num > 0){
	echo "<p>There (is) are currently $num messenger(s)</p>";
	echo "
	<table align='center' cellspacing='3' cellpadding='1' width='50%'>
	<tr>
		<td align='left'><a href='viewMessengers.php?sort=firstName'><b><p>First Name</p></b></a></td>
		<td align='left'><a href='viewMessengers.php?sort=lastName'><b><p>Last Name</p></b></a></td>
		<td align='left'><a href='viewMessengers.php?sort=email'><b><p>Email</p></b></a></td>
		<td align='left'><a href='viewMessengers.php?sort=messageSentDate'><b><p>Message Sent Date</p></b></a></td>
	</tr> ";
	
	$backgroundColor = 'silver';
	while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
		$backgroundColor = $backgroundColor=='silver' ? 'white' : 'silver';
			echo '<tr bgcolor="' . $backgroundColor . '">
			<td align="left">' . $row['firstName'] . '</td>
			<td align="left">' . $row['lastName'] . '</td>
			<td align="left">' . $row['email'] . '</td>
			<td align="left">' . $row['date'] . '</td>
			<td><a href="deleteMessengers.php?id=' . $row['id'] .'">Delete</a></td>
			</tr>';
		}
		
	echo '</table>';
	mysqli_free_result ($r);
} else {
	echo "<p>No users exist</p>";
	//Debugger
	//echo mysqli_error($dbc) . $q;
}
mysqli_close($dbc);

//Setting the page selection
if ($pages > 1){
	echo '<br><p>';
	$current_page = ($start/$display) + 1;
	if ($current_page != 1){
		echo '<a href="viewMessengers.php?s=' . ($start - $display) . '&p=' . $pages . '$sort=' . $sort . '">Previous </a>';
	}
	for ($i = 1; $i <= $pages; $i++){
		if ($i != $current_page){
			echo '<a href="viewMessengers.php?s=' . (($display * ($i - 1))) . '&p=' . $pages . '&sort=' . $sort . '">' . $i .'</a> ';
		} else {
			echo $i . ' ';
		}
	}
	if ($current_page != $pages) {
		echo '<a href="viewMessengers.php?s=' . ($start + $display) . '&p=' . $pages . '&sort=' . $sort . '">Next</a>';
	}
}


?>
<?php
include ("./includes/footer.inc.html");
exit();
?>