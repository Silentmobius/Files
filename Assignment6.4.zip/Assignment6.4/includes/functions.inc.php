<?php
function welcome($name) {
	echo "<p>Welcome $name</p>";
}


?>