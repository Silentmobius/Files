<?php
	function redirect_user ($page = 'index.php'){
		$url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
		$url = rtrim($url, '/\\');
		$url .= '/' . $page;
		
		header("Location: $url");
		exit();
	}
	
	//Returns $row['ASSOC'] or $errors[];
	function check_login($dbc, $username = '', $pass = '') {
		$errors = array();
		
		if (empty($username)){
			$errors[] = '<p>You forgot to enter your username.</p>';
		} else {
			$username = mysqli_real_escape_string($dbc, trim($username));
		}
		if (empty($pass)){
			$errors[] = '<p>You forgot to enter a password</p>';
			
		} else {
			$password = mysqli_real_escape_string($dbc, trim($pass));
		}
		
		if (empty($errors)){
			$q = "SELECT id, username, pass_hash FROM users WHERE username ='$username'";
			$r = mysqli_query($dbc, $q);
			if (mysqli_num_rows($r) == 1) {
				$row = mysqli_fetch_array($r, MYSQLI_ASSOC);
					if (!password_verify($password, $row['pass_hash'])) {
					$errors[] =  '<p>Invalid password!</p>';
					} else {
						return array(true, $row);
					}
			} else {
				$errors[] = '<p>User not found in the database</p>';
			}
		}
		return array(false, $errors);
	}
	function check_languages($dbc, $oldLanguage = '', $oldTier = '') {
		$errors = array();
		
		if (empty($oldLanguage)){
			$errors[] = '<p>You forgot to enter the language.</p>';
		} else {
			$oldLanguage = mysqli_real_escape_string($dbc, trim($oldLanguage));
		}
		if (empty($oldTier)){
			$errors[] = '<p>You forgot to select a tier</p>';
			
		} else {
			$oldTier = mysqli_real_escape_string($dbc, trim($oldTier));
		}
		
		if (empty($errors)){
			
			$q = "SELECT id, Language, Tier_id FROM Programming_Languages WHERE Language = '$oldLanguage';";
			$r = mysqli_query($dbc, $q);
			if (mysqli_num_rows($r) == 1) {
				$row = mysqli_fetch_array($r, MYSQLI_ASSOC);
					if ($oldTier != $row['Tier_id']) {
					$errors[] =  '<p>Tier is incorrect</p>';
					} else {
						return array(true, $row);
					}
			} else {
				$errors[] = '<p>Language not found in the database</p>';
			}
		}
		return array(false, $errors);
	}
