<?php 
if (isset($_GET['id'])){
$id = $_GET['id'];
$q = "SELECT Language, Tier_id from Programming_Languages where id = $id;";
$r = mysqli_query($dbc, $q);
	if ($r) {
		$row = mysqli_fetch_array($r, MYSQLI_ASSOC);
		$getOldLanguage = $row['Language'];
		$getOldTier = $row['Tier_id'];
	}
}

if (isset($errors) && !empty($errors)){
	echo '<h1>Error!</h1>
	<p class="error">The following error(s) have occured.</p>';
	foreach ($errors as $msg){
		echo "$msg\n";
	}
	echo '<p>Please try again</p>';
}
?>
<h1>Update Language</h1>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <fieldset>
    <legend><p>Change Language</p></legend>
	<p>Required *</p>
    <p>Language: *</p>
    <input type="text" name="oldLanguage" value="<?php echo isset($getOldLanguage) ? $getOldLanguage : '' ?>"><br>
    <p>New Language: *</p>
    <input type="text" name="newLanguage" value=""><br>
	<p>Tier *</p>
		<select name="oldTier">
		<option></option>
		<option value="1" <?php echo (isset($getOldTier) AND $getOldTier == 1) ? 'selected' : ''?>>Front-end</option>
		<option value="2" <?php echo (isset($getOldTier) AND $getOldTier == 2) ? 'selected' : ''?>>Back-end</option>
		<option value="3" <?php echo (isset($getOldTier) AND $getOldTier == 3) ? 'selected' : ''?>>Object-Oriented</option>
		<option value="4" <?php echo (isset($getOldTier) AND $getOldTier == 4) ? 'selected' : ''?>>Other</option>
		</select>
	<p>New Tier *</p>
		<select name="newTier">
		<option></option>
		<option value="1">Front-end</option>
		<option value="2">Back-end</option>
		<option value="3">Object-Oriented</option>
		<option value="4">Other</option>
		</select><br><br>
    <input type="submit" value="Submit"><br><br>
  </fieldset><br><br><br><br>
</form>

